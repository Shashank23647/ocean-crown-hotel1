document.getElementById("bookingForm").addEventListener("submit", function(e){

e.preventDefault()

alert("Thank you! Your booking inquiry has been sent.")

})